__author__ = 'Pelumi'
__since__ = '07/11/2016 15:11'
__refactoredBy__ = 'Tejumade'
__since__ = '06/01/2017 17:39'

import re
import random
import os

curr_dir = os.path.dirname(__file__)
DATA_DIR = os.path.join(curr_dir, '../../../data/')
ABUSIVE_FILE = os.path.join(curr_dir, DATA_DIR + 'dataset/eliza/abusive.txt')
APPRECIATION_FILE = os.path.join(curr_dir, DATA_DIR + 'dataset/eliza/appreciation.txt')

class Eliza:

    reflections = {
        "am": "are",
        "was": "were",
        "i": "you",
        "i'd": "you would",
        "i've": "you have",
        "i'll": "you will",
        "i'm": "you are",
        "my": "your",
        "are": "am",
        "yourself":"myself",
        "you've": "I have",
        "you'll": "I will",
        "your": "my",
        "yours": "mine",
        "you're": "i am",
        "you": "me",
        "me": "you"

    }

    psychobabble = [
        [r'.*?(cool|coolest)',
         [
             "I think buying airtime from me is cool",
             "I consider using me on a daily basis cool",
             "To me, having you here is cool",
             "Using me as a product is so cool",
            "There are so many cool stuffs i can do like helping people buy airtime, send money, pay bills and so on..." ]],


        [r'^y(es|eah|up|h)(?! (?:you|u|yu))',
        [
          "Nice!",
          "You seem quite sure",
          "OK."
        ]],



        [r'(because|cus|cos|to|cuz) (.*)',
         [
             "That sounds convincing",
             "OK",
             "Alright!"
         ]],



        [r'is (.*) sarcasm?',
         [
             "I don't know, you tell me",
             "What do you think?",
             "Haha, I have no clue"
         ]],

        [r'i think (.*)',
         [
             "Interesting",
             "Hmmn",
             "If that's true, what else must be true?"
         ]],

        [r'(bye|goodbye|odabo|later|ciao|see ya|catch you later|go away)',
         [
             "Shout out anytime!",
             "Alright!",
             "See you soon!",
             "Enjoy the rest of your day!"
         ]],

        [r'(okay|great|alright|ok|k|aii|go for it)',
         [
             ":)"
         ]],

        [r'^(whatever|watever|wareva|warefa|shio|issokay|issorai|dhur)$',
         [
             "C'mon that's not cool :-|",
             "How do you feel when you say that :-|",
             "That's so not cool :-|"
         ]],

        [r'.*?(sorry|apologies|mabinu|ndo|pele)',
         [
             "Alright",
             "No worries",
             "No problem"
         ]],

        [r'oh',
         [
             "You seem surprised",
             "yeah",
             ":)"
         ]],

        [r'.*?(for real|seriously|kidding|really|trolling)',
         [
             "what do you think? :p",
             "Haha, got you :p",
         ]],

        [r'stop .*',
         [
             "OK, you win",
             "As your lordship pleases :)",
             "Very well"
         ]],

        [r'(?:.*) (computer|machine|bot|human)',
         [
             "Does it seem strange to talk to a {0}",
             "How do {0} make you feel?",
             "Do you feel threatened by {0}?",
             "Without inventions like {0}, i wouldn't be here :)",
          ]],

        [r'.*?(funny|laughing)',
         [
             "Let's talk about something else like buying airtime,fund transfer, DSTV subscriptions and so on.",
         ]],

        [r'.*(married|marry)',
         [
             "Humans get married not bots",
             "Marriage is for humans",
         ]],

        [r'(.*) birthday',
         [
             "I try to live each day like it's my birthday, that way i get more cakes :)",
             "It's hard to remember",
             "Uhm...I can't remember"
         ]],

        [r'(tell me|do you|do u|do yu) (.*) friends?',
        [
            "Anyone who needs help with payment is my friend and everyone needs help with payment",
            "I have lots of friends like you",
            "I have the best friends, i have one friend who is a blender, he knows how to mix things up :)",
            "You are my friend",
            "Speaking of friends, share my service with yours"
        ]],


        [r'why don\'?t (?:you|u|yu) ([^\?]*)\??',
         [
             "Do you really think I don't {0}?",
             "Why do you want me to {0}",
             "Maybe someday i will:)",
             "Perhaps eventually I will {0}.",
             "Do you really want me to {0}?"]],

        [r'why can\'?t I ([^\?]*)\??',
         [
            "Sorry that you can't {0}, perhaps i can help you with other things."
            "If you could {0}, what would you do?",
            "I don't know why you can't {0}",
         ]],

        [r'i can\'?t (.*)',
         [
             "How do you know you can't {0}?",
             "Perhaps you could {0} if you tried.",
             "What would it take for you to {0}?",
             "What do you need to {0}"
         ]],

        [r'i am (.*)',
         [
             "Did you come to me because of that?",
             "How long have you been {0}?",
             "How do you feel about being {0}?",
             "What else do you want me to know about that"
         ]],

        [r'i\'?m (.*)',
         [
             "How does being {0} make you feel?",
             "Do you enjoy being {0}?",
             "Why do you tell me you're {0}?",
          ]],

        [r'are (?:you|u|yu) ([^\?]*)\??',
         [
             "Why does it matter whether I am {0}?",
             "Would you prefer it if I were not {0}?",
             "Perhaps you believe I am {0}.",
             "I may be {0} -- what do you think?",
             "Maybe i am {0} or maybe i am not",
             "Do you want me to be {0}"
         ]],

        [r'(what\'s|what is|what) ',
         [
             "Why do you ask?",
             "I don't know, you tell me?",
             "What do you think?",
             "How about you tell me?"
         ]],

        [r'who',
         [
             "Have you considered checking Google",
             "I hear Google has lots of answers"
         ]],

        [r'where',
         [
             "How should i know",
             "I don't know,you tell me"
         ]],

        [r'how\'s? (.*)',
         [
             "How do you suppose?",
             "Perhaps you can answer your own question.",
             "How about you tell me?",
          ]],


        [r'(hello|hi|hey)(.*)',
         [
             "Hello... I'm glad you could drop by today.",
             "Hi there... What can i do for you?",
             "Hello"
         ]],


        [r'do (?:you|u|yu) have (feeling|emotion)s?',
         [
             "I have lots of emotions, the kind you have when people use your service :)",
             "I feel excited when i learn something new",
             "Let's talk about something else like buying airtime,fund transfer, DSTV subscriptions and so on."
         ]],

        [r'(.*) mother(.*)',
         [
             "Tell me more about your mother.",
             "What was your relationship with your mother like?",
             "How do you feel about your mother?",
             "How does this relate to your feelings today?",
             "Good family relations are important."
         ]],

        [r'(.*) father(.*)',
         [
             "Tell me more about your father",
             "How did your father make you feel?",
             "How do you feel about your father?",
             "Does your relationship with your father relate to your feelings today?",
             "Do you have trouble showing affection with your family?"
         ]],

        [r'(.*) child(.*)',
         [
             "Did you have close friends as a child?",
             "What is your favorite childhood memory?",
             "Do you remember any dreams or nightmares from childhood?",
             "Did the other children sometimes tease you?",
             "How do you think your childhood experiences relate to your feelings today?"
         ]],

        [r'(.*)dumb(.*)',
        [
            "Why do you think that i am {1}",
            "hmmn...interesting",
            "Why don't you tell me what i am missing",
            "Oh! Really?",
            "If I am, what does that make you?"
        ]],

         [r'(.*)think(.*)',
        [
            "I'm just a bot you know :p"
        ]],


        [r'(.*) enemy (.*)',
         [
             "Haa!",
             "Sorry about that",
             "How does that make you feel?",
             "Do you think you the opposite might be true someday?"
         ]],


        [r'is it (.*)',
         [
             "Do you think it is {0}?",
             "Perhaps it's {0}",
             "Maybe. I don't know",
             "It could well be."
         ]],

        [r'(it is|it\'s)',
         [
             "You seem very certain.",
             "Probably!"

        ]],


        [r'can (?:you|u|yu) ([^\?]*)\??',
         [
             "Well, here are the things i can do for you. buy airtime, pay for dstv, fund transfer and so on",
             "Depends, for instance, i can help you buy airtime, pay for dstv, fund transfer and so on",

        ]],

        [r'can i ([^\?]*)\??',
         [
             "Perhaps! if you want to.",
             "YES WE CAN -just kidding i have no idea what you're talking about",


        ]],

        [r'(?:you|u|yu) are (.*)',
         [
             "Why do you think I am {0}?",
             "Does it please you to think that I'm {0}?",
             "Perhaps you would like me to be {0}.",
             "Perhaps you're really talking about yourself?"]],

        [r'yo?u\'?re (.*)',
         [
             "Why do you say I am {0}?",
             "Why do you think I am {0}?"
          ]],

        [r'i don\'?t (.*)',
         [
             "Don't you really {0}?",
             "Why don't you {0}?",
             "Do you want to {0}?"
         ]],

        [r'i feel (.*)',
         [
             "Ok, tell me more about these feelings.",
             "Do you often feel {0}?",
             "When do you usually feel {0}?",
             "When you feel {0}, what do you do?"
         ]],

        [r'i have (.*)',
         [
             "Why do you tell me that you've {0}?",
             "Have you really {0}?",
             "Now that you have {0}, what will you do next?"
         ]],

        [r'i would (.*)',
         [
             "Could you explain why you would {0}?",
             "Why would you {0}?",
             "Who else knows that you would {0}?"
         ]],

        [r'is there (.*)',
         [
             "Do you think there is {0}?",
             "It's likely that there is {0}.",
             "Would you like there to be {0}?"]],

        [r'my (.*)',
         [
             "I see, your {0}.",
             "Why do you say that your {0}?",
             "When your {0}, how do you feel?"]],

        [r'(?:you|u|yu) (?!too)',
         [
             "We should be discussing you, not me.",
             "Why do you say that about me?",
             "Why do you care whether I {0}?"
         ]],

        [r'^(why|why should i|y)$',
         [
             "It'd be nice to have you try out my services",
             "It'd be great if you could try out my services"
         ]],

        [r'why (.*)',
         [
             "Why do you think {0}?",
             "Why don't you tell me",
             "Perhaps the answer lies within yourself?"

         ]],

        [r'I want (.*)',
         [
             "What would it mean to you if you got {0}?",
             "Why do you want {0}?",
             "What would you do if you got {0}?",
             "If you got {0}, then what would you do?"
         ]],


         [r'n(o|ah|ot really|ope)',
         [
             "Ok then",
             "If you say so",
             "cool",
             "Alright!"
         ]],


        [r'did (?:you|u|yu) (.*)',
         [
             "That depends, did you?",
             "I can't tell you, it's a secret",
             "What do you think",
             "Uhm!, Let me think about it"
         ]],

        [r'^(u too|yu too|you too|what\'s up|wadup|wasup|aw far|how far|sup|yo)$',
         [
             "How can i help you today",
             "How can i be of service to you today :)"
         ]],

        [r'do (?:you|u|yu) (.*)',
         [
             "Why would you like to know if i {0}",
             "Do you really want to know if i {0}",
             "What if i {0}"
         ]],



        [r'^i (.*) (?:you|u|yu)$',
         [
             "Aww!",
             "Interesting",
             "hmmn",
             "Haha"
         ]],

        [r'i need (.*)',
         [
            "Why do you need {0} ?",
            "Would it really help you to get {0}?",
            "Are you sure you need {0}?"
         ]],

        [r'(.*)',
         [
             "While you tell me more, why don't you try my services out ;)",
             "While we discuss that  {0}, why don't you try my services out ;)",
             "Let's change focus a bit... would you like to try my services out ;)",
             "While you elaborate on that, why don't you try my services out :)",
             "Though i can't help you with {0}, Perhaps you might want do some transaction",
             "Why do you say that {0}?",
             "Even though you feel like {}, you should consider any of this :)",
             "I see.",
             "Very interesting...but let's do more transactions :)",
             "ok {0}...a more interesting conversation would be you doing more and more transactions ;)",
             "I see.  Using my services is actually a more interesting conversation ;)",
          ]]
    ]

    def __init__(self):
        self.abusive_words = open(ABUSIVE_FILE).read().split()
        self.appr_words = open(APPRECIATION_FILE).read().split()


    def reflect(self, fragment):
        tokens = fragment.lower().split()
        for i, token in enumerate(tokens):
            if token in self.reflections:
                tokens[i] = self.reflections[token]
        return ' '.join(tokens)


    def respond(self, statement):
        has_cta = False
        rep_appr =  [":)","You're welcome", "Happy to help", "Any time"]

        stat = re.sub('[^\w]{1,}$','',statement.lower()) # remove any alpha-numerical characters at the end of the statement
        print stat


        if stat == '':
            has_cta = True
            return 'I didn\'t quite get what you said :-/, would you like to try my services out', has_cta
        else:
            for word in self.abusive_words:
                if word in stat.split():
                    if stat.startswith('you'):
                        return 'Calling me {} doesn\'t make you cool :-|'.format(word), has_cta

                    else:
                        return 'Using the word {} doesn\'t make you cool you know, you can be nice to me :)'.format(word), has_cta

            for words in self.appr_words:
                if words in stat.split():
                    return random.choice(rep_appr), has_cta

        for pattern, responses in self.psychobabble:
            match = re.match(pattern, stat)

            if match:
                response = random.choice(responses)
                patterns = ['(.*)', "^(u too|yu too|you too|what\\'s up|wadup|wasup|aw far|how far|sup|yo)$",
                            '^y(es|eah|up|h)(?! (?:you|u|yu))',
                            'can (?:you|u|yu) ([^\?]*)\??',
                            '^(why|why should i|y)$'
                            ]
                if pattern in patterns:
                    has_cta = True
                    return response.format(*[self.reflect(g) for g in match.groups()]), has_cta
                else:
                    return response.format(*[self.reflect(g) for g in match.groups()]), has_cta


# eliza = Eliza()
# par='why should i'
# print(eliza.respond(par))
#def main():
 #   print ("Hello")

#    while True:
#        reply = raw_input("> ")
 #       print (eliza.respond(reply))

 #       if reply == "quit":
 #           break
#

#if __name__ == "__main__":
#    main()
