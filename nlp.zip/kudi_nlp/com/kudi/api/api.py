import logging
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from flask import Flask, request
from flask_restful import reqparse
from flask_restful import Resource, Api

from eliza.eliza import Eliza
from gibberish.gibberish_clf import GibberClf
from intent.intent_clf_txt_cat import IntentDetection
from ner.ner import NerHelper


__author__ = 'Pelumi'
__since__ = '29/10/2016 12:36'


app = Flask(__name__)
api = Api(app)

logger = logging.getLogger()
handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s %(name)-12s %(levelname)-8s %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.setLevel(logging.INFO)

class NerApi(Resource):
    ner_model = NerHelper()

    def post(self):
        text = request.form['text']
        response = self.ner_model.tag_text(text)
        logger.info('[Entity] Request: %s :::: Response: %s', text, response)
        return response

class IntentClfApi(Resource):
    intent_model = IntentDetection(load_model=True)

    def post(self):
        text = request.form['text']
        response = self.intent_model.get_intent(text)
        logger.info('[Intent] Request: %s :::: Response: %s', text, response)
        return response

class GibberishApi(Resource):
    gibberish_clf = GibberClf()

    def post(self):
        text = request.form['text']
        prediction, confidence = self.gibberish_clf.detect(text)
        response = {'clf_class': prediction, 'confidence': confidence}
        logger.info('[Gibberish] Request: %s :::: Response: %s', text, response)
        return response

class ElizaApi(Resource):
    eliza = Eliza()
    def post(self):
        text = request.form['text']
        reply, has_cta = self.eliza.respond(text)
        response = {'answer': reply, 'question': text, 'quick_reply': has_cta}
        logger.info('[Eliza] Request: %s :::: Response: %s', text, response)
        return response

api.add_resource(NerApi, '/nlp/ner')
api.add_resource(GibberishApi, '/nlp/gibberish')
api.add_resource(IntentClfApi, '/nlp/intent')
api.add_resource(ElizaApi, '/nlp/eliza')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=os.environ['PORT'], debug = False)
