import pickle
import math
import os

curr_dir = os.path.dirname(__file__)
DATA_DIR = os.path.join(curr_dir, '../../../data/')

SAVED_MODEL_FILE = os.path.join(curr_dir, DATA_DIR + 'models/gibberish/gibberish_model.pkl')
#DATASET FILES
GOOD_TEXT_FILE = os.path.join(curr_dir, DATA_DIR + 'dataset/gibberish/good.txt')
BIG_TEXT_FILE = os.path.join(curr_dir, DATA_DIR + 'dataset/gibberish/big.txt')
BAD_TEXT_FILE = os.path.join(curr_dir, DATA_DIR + 'dataset/gibberish/bad.txt')

#model_data = pickle.load(open(PICKLE_FILE, 'rb'))
accepted_chars = 'abcdefghijklmnopqrstuvwxyz '
pos = dict([(char, idx) for idx, char in enumerate(accepted_chars)])

class GibberClf:

    def detect(self, text):
        model_data = pickle.load(open(SAVED_MODEL_FILE, 'rb'))
        model_mat = model_data['mat']
        threshold = model_data['thresh'] - 0.008 #utter madness, hack to lower the threshold
        #TODO confidence should be calculated with respect to threshold, it's not an absolute value
        #Confidence Value
        probability = self.avg_transition_prob(text, model_mat)
        print self.avg_transition_prob(text, model_mat) > threshold
        #class
        predicition = probability > threshold
        return str(predicition), "{0:.2f}".format(probability)

    def normalize(self,line):
        """ Return only the subset of chars from accepted_chars.
        This helps keep the  model relatively small by ignoring punctuation,
        infrequenty symbols, etc. """
        return [c.lower() for c in line if c.lower() in accepted_chars]

    def ngram(self,n, l):
        """ Return all n grams from l after normalizing """
        filtered = self.normalize(l)
        for start in range(0, len(filtered) - n + 1):
            yield ''.join(filtered[start:start + n])

    def train(self):
        """ Write a simple model as a pickle file """
        k = len(accepted_chars)
        # Assume we have seen 10 of each character pair.  This acts as a kind of
        # prior or smoothing factor.  This way, if we see a character transition
        # live that we've never observed in the past, we won't assume the entire
        # string has 0 probability.
        counts = [[10 for i in xrange(k)] for i in xrange(k)]

        # Count transitions from big text file, taken
        # from http://norvig.com/spell-correct.html
        for line in open(BIG_TEXT_FILE):
            for a, b in self.ngram(2, line):
                counts[pos[a]][pos[b]] += 1

        # Normalize the counts so that they become log probabilities.
        # We use log probabilities rather than straight probabilities to avoid
        # numeric underflow issues with long texts.
        # This contains a justification:
        # http://squarecog.wordpress.com/2009/01/10/dealing-with-underflow-in-joint-probability-calculations/
        for i, row in enumerate(counts):
            s = float(sum(row))
            for j in xrange(len(row)):
                row[j] = math.log(row[j] / s)

        # Find the probability of generating a few arbitrarily choosen good and
        # bad phrases.
        good_probs = [self.avg_transition_prob(l, counts) for l in open(GOOD_TEXT_FILE)]
        bad_probs = [self.avg_transition_prob(l, counts) for l in open(BAD_TEXT_FILE)]

        # Assert that we actually are capable of detecting the junk.
        # if min(good_probs) > max(bad_probs):
        #   print "::"

        assert min(good_probs) > max(bad_probs)

        # And pick a threshold halfway between the worst good and best bad inputs.
        thresh = (min(good_probs) + max(bad_probs)) / 2
        pickle.dump({'mat': counts, 'thresh': thresh}, open(SAVED_MODEL_FILE, 'wb'))
          # And pick a threshold halfway between the worst good and best bad inputs.

    def avg_transition_prob(self, l, log_prob_mat):
        """ Return the average transition prob from l through log_prob_mat. """
        log_prob = 0.0
        transition_ct = 0
        for a, b in self.ngram(2, l):
            log_prob += log_prob_mat[pos[a]][pos[b]]
            transition_ct += 1
        # The exponentiation translates from log probs to probs.
        return math.exp(log_prob / (transition_ct or 1))

#clf = GibberClf()
#clf.train()

#print clf.detect("dbanj")
