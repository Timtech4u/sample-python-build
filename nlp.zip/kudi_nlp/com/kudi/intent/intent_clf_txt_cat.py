import string

from spacy.en import English
import os
import pandas as pd
from mitie import text_categorizer_trainer, text_categorizer

__author__ = 'Pelumi'
__since__ = '30/10/2016 16:42'

vocab_file = '../data/glove_wiki/glove.6B.100d.txt'
vectors_file = '../data/glove_wiki/glove.6B.100d.txt'

curr_dir = os.path.dirname(__file__)
DATA_DIR = os.path.join(curr_dir, '../../../data/')
GLOVE_6B_50D_PATH = DATA_DIR + 'models/glove/glove.6B.50d.txt'
GLOVE_6B_100D_PATH = DATA_DIR + 'models/glove/glove.6B.100d.txt'
WORD_FEATURE_EXTRACTOR = DATA_DIR + 'models/ner/total_word_feature_extractor.dat'
INTENT_DIR = DATA_DIR + 'models/intent'
INTENT_MODEL = INTENT_DIR + '/kudi_mitie_intent_model.dat'

nlp = English()

class IntentDetection:
    def __init__(self, load_model=True):
        if load_model:
            self.intent_model = text_categorizer(INTENT_MODEL)

    def load_clf_dataset(self, filename):
        raw_dataset = pd.read_fwf(filename, skipinitialspace=True, header = 0)
        raw_dataset['Text'] = raw_dataset['Text'].str.strip()
        raw_dataset.drop_duplicates(inplace=True)
        df_list = raw_dataset['Text'].values.tolist()
        return df_list

    def tokenizeText(self, text):
        # get the tokens using spaCy
        tokens = nlp(unicode(text))

        # remove all whitespace charactes
        tokens = [t for t in tokens if not t.is_space]

        # map to lowercase unicode
        tokens = map(lambda t: t.lower_, tokens)

        return tokens

    def train_model(self):
        if not os.path.exists(INTENT_DIR):
            print 'Making intent directory...'
            os.makedirs(INTENT_DIR)

        print 'training...'

        trainer = text_categorizer_trainer(WORD_FEATURE_EXTRACTOR)
        filename = DATA_DIR + 'dataset/intent/{}_dataset.csv'
        data = {
            "greeting": {
                "examples": self.load_clf_dataset(filename.format('greeting')),
                "centroid": None
            },
            "appreciation": {
                "examples": self.load_clf_dataset(filename.format('appreciation')),
                "centroid": None
            },
            "balance": {
                "examples": self.load_clf_dataset(filename.format('balance')),
                "centroid": None
            },
            "excitement": {
                "examples": self.load_clf_dataset(filename.format('excitement')),
                "centroid": None
            },
            "dstv_bill": {
                "examples": self.load_clf_dataset(filename.format('dstv_bill')),
                "centroid": None
            },
            "gotv_bill": {
                "examples": self.load_clf_dataset(filename.format('gotv_bill')),
                "centroid": None
            },
            "insult_bill": {
                "examples": self.load_clf_dataset(filename.format('insult')),
                "centroid": None
            },
            "topup_bill": {
                "examples": self.load_clf_dataset(filename.format('topup')),
                "centroid": None
            },
            "transfer_bill": {
                "examples": self.load_clf_dataset(filename.format('transfer')),
                "centroid": None
            },
            "cancellation_bill": {
                "examples": self.load_clf_dataset(filename.format('cancellation')),
                "centroid": None
            },
            "phcn_bill": {
                "examples": self.load_clf_dataset(filename.format('phcn_bill')),
                "centroid": None
            },
        }

        for label in data.keys():
            for text in data[label]["examples"]:
                tokens = self.tokenizeText(text)
                trainer.add_labeled_text(tokens, label)

        trainer.num_threads = 4
        cat = trainer.train()

        cat.save_to_disk(INTENT_MODEL)
        toks = self.tokenizeText("i need a dstv sub")
        predicted_label, _ = cat(toks)

    def try_resolve_transfer_to_topup(self, text):
        text = text.lower()
        topup_keywords = ['mtn', 'glo', 'airtel', 'etisalat', 'airtime', 'topup', 'credit', 'recharge', 'card']
        if any(ext in text for ext in topup_keywords):
            return 'topup'

        return 'transfer'

    def try_resolve_topup_to_transfer(self, text):
        text = text.lower()
        transfer_keywords = ['bank', 'account', 'transfer', 'gtb', 'access', 'zenith', 'diamond', 'stanbic', 'heritage', 'money', 'monies', 'cash']
        if any(ext in text for ext in transfer_keywords):
            return 'transfer'

        return 'topup'

    def get_intent(self, text):
        text_tokens = self.tokenizeText(text)
        label, score = self.intent_model(text_tokens)
        if 'transfer' in label:
            label = self.try_resolve_transfer_to_topup(text)

        elif 'topup' in label:
            label = self.try_resolve_topup_to_transfer(text)

        return [{'clf_class': string.replace(label, '_bill', ''), 'confidence': "{0:.2f}".format(score)}]

# intent_clf = IntentDetection(load_model=False)
# intent_clf.train_model()
# print intent_clf.get_intent("i need a dstv sub")
# print intent_clf.get_intent("i need mtn recharge card")
# print intent_clf.get_intent("buy me #200 airtime")
# print intent_clf.get_intent("i need some credit")
# print intent_clf.get_intent("if you say send 5k to tunde")
# print intent_clf.get_intent("Please send credit to 080342666064")
# print intent_clf.get_intent("please send credit to mum")
# print intent_clf.get_intent("send 200naira to busayo")
# print intent_clf.get_intent("bullshit")
# print intent_clf.get_intent("hola")
# print intent_clf.get_intent("yo")
