from spacy.en import English

__author__ = 'Pelumi'
__since__ = '30/10/2016 16:42'

import numpy as np
import os
vocab_file = '../data/glove_wiki/glove.6B.100d.txt'
vectors_file = '../data/glove_wiki/glove.6B.100d.txt'


curr_dir = os.path.dirname(__file__)
DATA_DIR = os.path.join(curr_dir, '../../../data/')
GLOVE_6B_50D_PATH = DATA_DIR + 'models/glove/glove.6B.50d.txt'
GLOVE_6B_100D_PATH = DATA_DIR + 'models/glove/glove.6B.100d.txt'

nlp = English()



class Embedding(object):
    def __init__(self, vocab_file, vectors_file):
        with open(vectors_file, 'r') as f:
            words = [x.rstrip().split(' ')[0] for x in f.readlines()]
            print (len(words))
        with open(vectors_file, 'r') as f:
            vectors = {}
            for line in f:
                vals = line.rstrip().split(' ')
                vectors[vals[0]] = [float(x) for x in vals[1:]]

        vocab_size = len(words)
        vocab = {w: idx for idx, w in enumerate(words)}
        ivocab = {idx: w for idx, w in enumerate(words)}

        vector_dim = len(vectors[ivocab[0]])
        # print vector_dim
        W = np.zeros((vocab_size, vector_dim))

        for word, v in vectors.items():
            if word == '<unk>':
                continue
            W[vocab[word], :] = v

        # normalize each word vector to unit variance
        W_norm = np.zeros(W.shape)
        d = (np.sum(W ** 2, 1) ** (0.5))
        with np.errstate(invalid='ignore'):
            W_norm = (W.T / d).T

        self.W = W_norm
        self.vocab = vocab
        self.ivocab = ivocab


def find_similar_words(embed, text, refs, thresh):
    C = np.zeros((len(refs), embed.W.shape[1]))

    for idx, term in enumerate(refs):
        if term in embed.vocab:
            C[idx, :] = embed.W[embed.vocab[term], :]

    tokens = text.split(' ')
    scores = [0.] * len(tokens)
    found = []

    for idx, term in enumerate(tokens):
        if term in embed.vocab:
            vec = embed.W[embed.vocab[term], :]
            cosines = np.dot(C, vec.T)
            score = np.mean(cosines)
            scores[idx] = score
            if (score > thresh):
                found.append(term)
    print (scores)

    return found


cuisine_refs = ["mexican", "chinese", "french", "british", "american"]
threshold = 0.5

text = "how can i make a french toast"

embed = Embedding(vocab_file, vectors_file)
cuisines = find_similar_words(embed, text, cuisine_refs, threshold)
print(cuisines)


def sum_vecs(embed, text):
    tokens = text.split(' ')
    vec = np.zeros(embed.W.shape[1])

    for idx, term in enumerate(tokens):
        if term in embed.vocab:
            vec = vec + embed.W[embed.vocab[term], :]
    return vec


def get_centroid(embed, examples):
    C = np.zeros((len(examples), embed.W.shape[1]))
    for idx, text in enumerate(examples):
        C[idx, :] = sum_vecs(embed, text)

    centroid = np.mean(C, axis=0)
    assert centroid.shape[0] == embed.W.shape[1]
    return centroid


def get_intent(embed, text):
    intents = ['deny', 'inform', 'greet']
    vec = sum_vecs(embed, text)
    scores = np.array([np.linalg.norm(vec - data[label]["centroid"]) for label in intents])
    return intents[np.argmin(scores)]


data = {
    "greet": {
        "examples": ["hello", "hey there", "howdy", "hello", "hi", "hey", "hey ho"],
        "centroid": None
    },
    "inform": {
        "examples": [
            "i'd like something asian",
            "maybe korean",
            "what mexican options do i have",
            "what italian options do i have",
            "i want korean food",
            "i want german food",
            "i want vegetarian food",
            "i would like chinese food",
            "i would like indian food",
            "what japanese options do i have",
            "korean please",
            "what about indian",
            "i want some vegan food",
            "maybe thai",
            "i'd like something vegetarian",
            "show me french restaurants",
            "show me a cool malaysian spot"
        ],
        "centroid": None
    },
    "deny": {
        "examples": [
            "nah",
            "any other places ?",
            "anything else",
            "no thanks"
            "not that one",
            "i do not like that place",
            "something else please",
            "no please show other options"
        ],
        "centroid": None
    }
}

for label in data.keys():
    data[label]["centroid"] = get_centroid(embed, data[label]["examples"])

for text in ["hey you", "i am hungry for an italian food", "what else have you got?"]:
    print ("text : '{0}', predicted_label : '{1}'".format(text, get_intent(embed, text)))