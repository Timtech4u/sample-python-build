import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd
from sklearn.cross_validation import cross_val_score
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB, BernoulliNB
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from spacy.en import English
from tabulate import tabulate

from vectorizers.CustomVectorizers import MeanEmbeddingVectorizer, TfidfEmbeddingVectorizer

__author__ = 'Pelumi'
__since__ = '29/10/2016 16:24'

curr_dir = os.path.dirname(__file__)
DATA_DIR = os.path.join(curr_dir, '../../../data/')
GLOVE_6B_50D_PATH = DATA_DIR + 'models/glove/glove.6B.50d.txt'
nlp = English()

INTENTS = {'1': 'BALANCE', '2': 'TOPUP', '3': 'TRANSFER', '4': 'GOTV_BILL', '5': 'DSTV_BILL', '6': 'PHCN_BILL',
           '7': 'INSULT', '8': 'APPRECIATION', '9': 'GREETING', '10': 'CANCELLATION', '11': 'EXCITEMENT'}

dataset_keys = {'1': 'balance', '2': 'topup'}#, '3': 'transfer', '4': 'gotv_bill', '5': 'dstv_bill', '6': 'phcn_bill',
     #      '7': 'insult', '8': 'appreciation', '9': 'greeting', '10': 'cancellation'}

def load_all_dataset():
    count = 0
    X, y = [], []
    for key in dataset_keys:
        count+=1
        filename = DATA_DIR + 'dataset/intent/' + dataset_keys[key] + '_dataset.csv'
        print filename
        class_df = load_clf_dataset(filename)
        for line in class_df['Text']:
            print line

            line = unicode(line,encoding="utf-8")

            #label, text = line.split("\t")
            # texts are already tokenized, just split on space
            # in a real case we would use e.g. spaCy for tokenization
            # and maybe remove stopwords etc.
            X.append(tokenizeText(line))
            y.append(key)
    X, y = np.array(X), np.array(y)
    print "total examples %s" % len(y)
    print y

    with open(GLOVE_6B_50D_PATH, "rb") as lines:
        word2vec = {line.split()[0]: np.array(map(float, line.split()[1:]))
                    for line in lines}
    glove_small = {}
    all_words = set(w for words in X for w in words)
    if 'let' in all_words:
        print 'let is in'
    with open(GLOVE_6B_50D_PATH, "rb") as infile:
        for line in infile:
            parts = line.split()
            word = parts[0]
            nums = map(float, parts[1:])
            if word in all_words:
                print word
                glove_small[word] = np.array(nums)

    print all_words
    print glove_small
    #glove_big = {}
    # with open(GLOVE_840B_300D_PATH, "rb") as infile:
    #     for line in infile:
    #         parts = line.split()
    #         word = parts[0]
    #         nums = map(float, parts[1:])
    #         if word in all_words:
    #             glove_big[word] = np.array(nums)

    # train word2vec on all the texts - both training and test set
    # we're not using test labels, just texts so this is fine
#    model = Word2Vec(X, size=100, window=5, min_count=1, workers=4)
 #   w2v = {w: vec for w, vec in zip(model.index2word, model.syn0)}

    # start with the classics - naive bayes of the multinomial and bernoulli varieties
    # with either pure counts or tfidf features
    mult_nb = Pipeline(
        [("count_vectorizer", CountVectorizer(analyzer=lambda x: x)), ("multinomial nb", MultinomialNB())])
    bern_nb = Pipeline([("count_vectorizer", CountVectorizer(analyzer=lambda x: x)), ("bernoulli nb", BernoulliNB())])
    mult_nb_tfidf = Pipeline(
        [("tfidf_vectorizer", TfidfVectorizer(analyzer=lambda x: x)), ("multinomial nb", MultinomialNB())])
    bern_nb_tfidf = Pipeline(
        [("tfidf_vectorizer", TfidfVectorizer(analyzer=lambda x: x)), ("bernoulli nb", BernoulliNB())])
    # SVM - which is supposed to be more or less state of the art
    # http://www.cs.cornell.edu/people/tj/publications/joachims_98a.pdf
    svc = Pipeline([("count_vectorizer", CountVectorizer(analyzer=lambda x: x)), ("linear svc", SVC(kernel="linear"))])
    svc_tfidf = Pipeline(
        [("tfidf_vectorizer", TfidfVectorizer(analyzer=lambda x: x)), ("linear svc", SVC(kernel="linear"))])
    etree_glove_small = Pipeline([("glove vectorizer", MeanEmbeddingVectorizer(word2vec)),
                                  ("extra trees", ExtraTreesClassifier(n_estimators=200))])


    etree_glove_small_tfidf = Pipeline([("glove vectorizer", TfidfEmbeddingVectorizer(word2vec)),
                                        ("extra trees", ExtraTreesClassifier(n_estimators=200))])
    # etree_glove_big = Pipeline([("glove vectorizer", MeanEmbeddingVectorizer(glove_big)),
    #                             ("extra trees", ExtraTreesClassifier(n_estimators=200))])
    # etree_glove_big_tfidf = Pipeline([("glove vectorizer", TfidfEmbeddingVectorizer(glove_big)),
    #                                   ("extra trees", ExtraTreesClassifier(n_estimators=200))])

    # etree_w2v = Pipeline([("word2vec vectorizer", MeanEmbeddingVectorizer(w2v)),
    #                       ("extra trees", ExtraTreesClassifier(n_estimators=200))])
    # etree_w2v_tfidf = Pipeline([("word2vec vectorizer", TfidfEmbeddingVectorizer(w2v)),
    #                             ("extra trees", ExtraTreesClassifier(n_estimators=200))])

    all_models = [
        ("mult_nb", mult_nb),
        ("mult_nb_tfidf", mult_nb_tfidf),
        ("bern_nb", bern_nb),
        ("bern_nb_tfidf", bern_nb_tfidf),
        ("svc", svc),
        ("svc_tfidf", svc_tfidf),
        ("glove_small", etree_glove_small),
        ("glove_small_tfidf", etree_glove_small_tfidf),
        #("glove_big", etree_glove_big),
        #("glove_big_tfidf", etree_glove_big),
        #("w2v", etree_w2v),
        #("w2v_tfidf", etree_w2v_tfidf),
    ]
    scores = sorted([(name, cross_val_score(model, X, y, cv=5).mean())
                     for name, model in all_models],
                    key=lambda (_, x): -x)
    print tabulate(scores, floatfmt=".4f", headers=("model", 'score'))

def tokenizeText(text):
    # get the tokens using spaCy
    tokens = nlp(text)

    # # lemmatize
    # lemmas = []
    # for tok in tokens:
    #     lemmas.append(tok.lemma_.lower().strip() if tok.lemma_ != "-PRON-" else tok.lower_)
    # tokens = lemmas

    # stoplist the tokens
    #tokens = [tok for tok in tokens if tok not in STOPLIST]
    tokens = [tok for tok in tokens]

    # stoplist symbols
    #tokens = [tok for tok in tokens if tok not in SYMBOLS]

    # remove large strings of whitespace
    while "" in tokens:
        tokens.remove("")
    while " " in tokens:
        tokens.remove(" ")
    while "\n" in tokens:
        tokens.remove("\n")
    while "\n\n" in tokens:
        tokens.remove("\n\n")

    return tokens

def load_clf_dataset(filename):
    raw_dataset = pd.read_fwf(filename, skipinitialspace=True, header =0)
    raw_dataset['Text'] = raw_dataset['Text'].str.strip()
    raw_dataset.drop_duplicates(inplace=True)
    return raw_dataset

    #print raw_dataset

# count = 0
# for key in dataset_keys:
#     count+=1
#     filename = DATA_DIR + 'dataset/intent/' + dataset_keys[key] + '_dataset.csv'
#     print filename
#     load_clf_dataset(filename)
#     if count == 1:
#         break


# toks = tokenizeText(u'i\'m gv guj')
# for tok in toks:
#     print tok

load_all_dataset()
