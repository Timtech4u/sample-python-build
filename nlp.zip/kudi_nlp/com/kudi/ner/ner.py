import os
import time

from mitie import tokenize, ner_training_instance, ner_trainer, named_entity_extractor
from NerTrainingInstance import NerDataInstance
from word2num import WordConversion

__author__ = 'Pelumi'
__since__ = '06/10/16 11:01'

CURR_DIR = os.path.dirname(__file__)
DATA_DIR = os.path.join(CURR_DIR, '../../../data/')
DATASET_FILE = os.path.join(CURR_DIR, DATA_DIR + 'dataset/ner/entities_dataset.txt')
WORD_FEATURE_EXTRACTOR_MODEL = os.path.join(CURR_DIR, DATA_DIR + 'models/ner/total_word_feature_extractor.dat')
KUDI_ENTITIES_MODEL = os.path.join(CURR_DIR, DATA_DIR + 'models/ner/kudi_entities_model.dat')

class NerHelper:
    def __init__(self, load_model=True):
        if load_model:
            self.ner_model = named_entity_extractor(KUDI_ENTITIES_MODEL)
            self.word2num = WordConversion()

            print 'All available NER tags are: ', self.ner_model.get_possible_ner_tags()

    def train_model(self, filename):
        start_time = time.time()

        ner_trainer_inst = ner_trainer(WORD_FEATURE_EXTRACTOR_MODEL)
        
        
        # for line in filename:
        with open(filename) as f:
            for line in f:
                ner_text_instance = NerDataInstance(line)
            

                    #TODO ignore instances without entities... think this through
                if ner_text_instance.has_no_entities():
                   continue
            

            instance = ner_training_instance(ner_text_instance.get_clean_text_tokens())

            for entity in ner_text_instance.text_entities:
                instance.add_entity(xrange(entity[0],entity[1]), entity[2])
                

            ner_trainer_inst.add(instance)

        #train and save model
        ner_model = ner_trainer_inst.train()
        ner_model.save_to_disk(KUDI_ENTITIES_MODEL)

        end_time = time.time()
        print "Total training time is: %s" % (end_time-start_time)


    def tag_text(self, text):
        #disable wor2num normalisation till validity check of normalised version is implemented
        #normalised_text = self.word2num.normalise_text(text)
        normalised_text = text
        norm_tokens = tokenize(normalised_text)
        extracted_entity = self.ner_model.extract_entities(norm_tokens)
        entity_data = []
        for entity in extracted_entity:
            entity_value = ''
            data = {}

            for i in entity[0]:
                entity_value = "%s %s" % (entity_value, norm_tokens[i])

            data['type'] = entity[1]
            data['value'] = entity_value.strip()
            data['threshold'] = entity[2]
            entity_data.append(data)

        return entity_data

        #remember to retrain


# ner = NerHelper(load_model=True)
# ner.train_model(DATASET_FILE)
#sample1 = "transfer five thousand to kasali"
#sample1Toks = tokenize(sample1)
#res1 = ner.tag_text(sample1)
#res2 = ner.tag_text("i need 34k in my GTB")

