import collections
import string
from mitie import tokenize
from sets import Set

__author__ = 'Pelumi'
__since__ = '06/10/16 21:15'

class NerDataInstance(object):

    def __init__(self, text):
        self.text_entities = []
        self.entity_types = Set([])
        self.clean_text = ''
        self.text = text
        self.parse(text)

    def has_no_entities(self):
        return not self.text_entities

    def get_entities(self):
        return self.text_entities

    def get_clean_text_tokens(self):
        return tokenize(self.clean_text)

    def parse(self, text):
        index = 0

        if '_' not in text:
            print "Data instance without tags found: ", text

        tokens = tokenize(text)
        Entity = collections.namedtuple('Entity', 'start end entity_type')

        clean_text_tmp = text

        for token in tokens:
            if '_' in token:
                start_index = index
                end_index = start_index + 1

                entity_tokens = token.split('_')
                clean_token = entity_tokens[0]
                entity_name = entity_tokens[1]
                if not entity_name:
                    print "Incorrectly tagged string: ", text
                instance_entity = Entity(start=start_index, end=end_index, entity_type=entity_name)
                self.text_entities.append(instance_entity)
                self.entity_types.add(entity_name)
                clean_text_tmp = string.replace(clean_text_tmp, token, clean_token)

            index += 1

        self.clean_text = clean_text_tmp