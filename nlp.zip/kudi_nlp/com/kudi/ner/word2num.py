import re

american_number_system = {
    'zero': 0,
    'one': 1,
    'two': 2,
    'three': 3,
    'four': 4,
    'five': 5,
    'six': 6,
    'seven': 7,
    'eight': 8,
    'nine': 9,
    'ten': 10,
    'eleven': 11,
    'twelve': 12,
    'thirteen': 13,
    'fourteen': 14,
    'fifteen': 15,
    'sixteen': 16,
    'seventeen': 17,
    'eighteen': 18,
    'nineteen': 19,
    'twenty': 20,
    'thirty': 30,
    'forty': 40,
    'fifty': 50,
    'sixty': 60,
    'seventy': 70,
    'eighty': 80,
    'ninety': 90,
    'hundred': 100,
    'thousand': 1000,
    'million': 1000000,
    'billion': 1000000000
}

class WordConversion(object):

    def __init__(self):
        self.clean = []
        self.clean_text = []
        self.text2num = []

    def word_to_num(self, text):
        in_text = text.lower().strip()
        # inputWordArr = re.split('[ -]', in_text)
        # print in_text, inputWordArr
        for word in in_text.split():
            if word in american_number_system:
                self.clean.append(word)
                # return self.clean
                # print american_number_system[word]

            else:
                self.clean = []
                inputWordArr = re.split('[ -]', in_text)
                for word in inputWordArr:
                    if word in american_number_system:
                        self.clean.append(word)
                # return self.clean
        if len(self.clean) == 0:
            return text

        billion_index = self.clean.index('billion') if 'billion' in self.clean else -1
        million_index = self.clean.index('million') if 'million' in self.clean else -1
        thousand_index = self.clean.index('thousand') if 'thousand' in self.clean else -1

        total_sum = 0
        if billion_index>-1 :
            billion_multiplier = self.number_formation(self.clean[0:billion_index])
            # print "billion_multiplier",str(billion_multiplier)
            total_sum += billion_multiplier * 1000000000

        if million_index>-1 :
            if billion_index>-1:
                million_multiplier = self.number_formation(self.clean[billion_index+1:million_index])
            else:
                million_multiplier = self.number_formation(self.clean[0:million_index])
            total_sum += million_multiplier * 1000000
            # print "million_multiplier",str(million_multiplier)

        if thousand_index > -1:
            if million_index > -1:
                thousand_multiplier = self.number_formation(self.clean[million_index+1:thousand_index])
            elif billion_index>-1 and million_index==-1:
                thousand_multiplier = self.number_formation(self.clean[billion_index+1:thousand_index])
            else:
                thousand_multiplier = self.number_formation(self.clean[0:thousand_index])
            total_sum += thousand_multiplier * 1000
            # print "thousand_multiplier",str(thousand_multiplier)

        if thousand_index>-1 and thousand_index != len(self.clean)-1:
            hundreds = self.number_formation(self.clean[thousand_index+1:])
        elif million_index>-1 and million_index != len(self.clean)-1:
            hundreds = self.number_formation(self.clean[million_index+1:])
        elif billion_index>-1 and billion_index != len(self.clean)-1:
            hundreds = self.number_formation(self.clean[billion_index+1:])
        elif thousand_index==-1 and million_index==-1 and billion_index==-1:
            hundreds = self.number_formation(self.clean)
        else:
            hundreds = 0
        total_sum += hundreds
        self.text2num.append(total_sum)
        # return  total_sum

        alof= False
        for i,orig in enumerate(text.split()):
            found = False
            for t in self.clean:
                if t in orig:
                    found = True
                    if not alof:
                        self.clean_text.append('$_')
                        alof = True
                    else:
                        self.clean_text.append('')
            if not found:
              self.clean_text.append(orig)
        text_refined = ' '.join(filter(lambda word: not word == '', self.clean_text))
        num2text = text_refined.replace('$_', str(self.text2num[0]))
        return num2text

    def number_formation(self, number_words):
        numbers = []
        for number_word in number_words:
            numbers.append(american_number_system[number_word])
        if len(numbers)==4:
            return (numbers[0]*numbers[1])+numbers[2]+numbers[3]
        elif len(numbers)==3:
            return numbers[0]*numbers[1] + numbers[2]
        elif len(numbers)==2:
            if 100 in numbers:
                return numbers[0]*numbers[1]
            else:
                return numbers[0]+numbers[1]
        else:
            return numbers[0]

    def normalise_text(self, text):
        return self.word_to_num(text)



