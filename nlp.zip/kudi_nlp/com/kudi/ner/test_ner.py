from ner.api.ner import NerHelper

__author__ = 'Pelumi'
__since__ = '11/10/2016 06:32'

#TODO create unit tests for the tagger something like what we have below

ner = NerHelper()
test1 = "transfer 5000 to kasali"
response1 = ner.tag_text(test1)
#assert expected response