# Kudi NLP #

This repo is home to all NLP related services on Kudi.

The service runs on port 7979 and the root is `/nlp`. All requests are POST

The four services here are:

* Intent Classifier `/nlp/intent` Param: `message`
* NER Module `/nlp/ner` Param: `text`
* Gibberish Detector `/nlp/gibberish` Param: `raw_text`
* Eliza `/nlp/eliza` Param: `text`

## Dependencies ##
* install anaconda for starters
* mitie
* scikit-learn
* spacy
* tabulate

## Model files are needed to run the code successfully: ##
* kudi_mitie_intent_model.dat
* glove files (needed for scikit based training)
* kudi_entities_model.dat
* total_word_feature_extractor.dat

## What else should I know ##
The service is always attached on the DO server but incase there's ever need to restart it   
* `source activate kudi_venv` already has the env set up
* you can `pip install requirements.txt` to set it up as well
* mitie can't be `pip install mitie` yet but you can get it by `pip install git+https://github.com/mit-nlp/MITIE.git`

### Who do I talk to? ###

* pelumi@kudi.ai
