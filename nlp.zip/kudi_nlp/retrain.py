from com.kudi.intent.intent_clf_txt_cat import IntentDetection

intent_clf = IntentDetection(load_model=False)
intent_clf.train_model()
